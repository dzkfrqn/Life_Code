@extends('Master')
@section('title','Home')
@section('content')

<div style="text-align: center">
    <div>
        <a href="/blog/add" class="btn btn-secondary" 
        role="button">+ Create Blog</a>
    </div>

    <div>
        <table class="table table-striped"> 
        <tr>
            <th scope="col">Title</th>
            <th scope="col">Action</th>
        </tr>
        @foreach($articles as $article)
        <tr>
             
                <td>{{$article->title}}</td>
                <td>
                    <form action="/blog/{{$article->id}}" method="post">
                        @Method('delete')
                        @csrf
                            <button class="btn btn-secondary">
                                delete
                            </button> 
                    </form>

                </td>
            
        </tr>
        @endforeach
        </table>
    </div>
</div>
@endsection