@extends('Master')
@section('title','Home')
@section('content')


<table class="table caption-top" style="margin-left: 50px; margin-right: 50px; margin-top: 15px;" >
  <thead>
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  @foreach($users as $user)
  <tbody>
    <tr>
      <td>
        <p><a href="#">{{$user->name}}</a></p>
      </td>
      <td><p>{{$user->email}}</p></td>
      <td>
            <form action="/homepage/{{$user->id}}/profile" method="post">
                        @method('DELETE')
                        @csrf
                        <button class="btn btn-outline-danger">Clear</button>
                    </form>
        </td>
    </tr>
    
  </tbody>
  @endforeach

  
</table>
@endsection
