@extends('Master')
@section('title','Home')
@section('content')


        <div class="card-body">  
        @foreach($articles as $article)   
            <div class="row">
                
                <div class="col-md-4">
                    <div class="card-body">
                        <h4 class="card-title"style="font:black;">
                        <p >{{$article->title}}</p>
                        </h4>                 
                        <p class="card-text text-muted">
                        {{substr($article->description, 0, 80)}} 
                        <a href="/homepage/{{$article->id}}/detail">...read more</a>
                        </p>
                    </div>
                </div>    
            </div>
             
                 @endforeach

        </div>    
    <div>
    {{$articles->links()}}
    </div>

@endsection