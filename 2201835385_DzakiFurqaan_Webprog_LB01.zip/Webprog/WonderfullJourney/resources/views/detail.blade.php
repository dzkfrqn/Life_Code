@extends('Master')
@section('title','Home')
@section('content')

<div class="container">
        <div class="row">
            <div class="col">
            <br>
            <img class="card-img rounded float-left" style="width: 400px;height:400px" 
                src="{{ Storage::url($article->image )}}" alt="image not found">  
            </div>
            <div class="col">
            
                <div class="col-7 card-body mx-auto">
                <h2>{{$article->title}}</h2>
                    <p class="text-justify card-text">{{$article->description}}</p>
                    <a class="btn btn-dark mt-auto ml-auto" href="{{ url()->previous() }}">Back</a>
                </div>

            </div>
        </div>
</div>
@endsection

