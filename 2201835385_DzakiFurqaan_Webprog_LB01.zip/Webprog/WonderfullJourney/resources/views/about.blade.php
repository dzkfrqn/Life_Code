@extends('Master')
@section('title','Home')
@section('content')


<h1 >

ini blog untuk uas

</h1>


@endsection