@extends('Master')
@section('title','Home')
@section('content')

<div>
    <h2>Updated Blog</h2>
    <div>
            <form class="px-5" action="/blog/add" method="post" enctype="multipart/form-data">
                <div>
                    <a>Title:</a>
                    <input class="form-control" type="text" autocomplete="off" name="title">
                    @error('title') 
                    <p style = "color: red;">{{$message}}</p> @enderror
                </div>
                <div>
                    <a>Category:</a>
                    <select class="form-control" id="category" name="category">
                        @foreach($categories as $category)
                            <option value="{{$category->id}}">{{$category->name}}</option>
                        @endforeach
                    </select>
                    @error('category') <p style = "color: red;">{{$message}}</p> @enderror
                </div>
                <div>
                    <a>image:</a>
                    <input class="form-control-file" type="file" autocomplete="off" name="image">
                    @error('image') <p style = "color: red;">{{$message}}</p> @enderror
                </div>
                <div>
                    <a>Description:</a>
                    <textarea rows="5" class="form-control" type="text" autocomplete="off" name="description"></textarea>
                    @error('description') <p style = "color: red;">{{$message}}</p> @enderror
                </div>
                @csrf
                <div>
                    <button class="btn btn-dark">Finish</button>
                </div>
            </form>
        </div>
</div>


@endsection