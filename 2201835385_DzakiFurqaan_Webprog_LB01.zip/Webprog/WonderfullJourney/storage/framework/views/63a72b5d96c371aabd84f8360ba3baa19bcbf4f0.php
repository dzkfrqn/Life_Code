
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>


<table class="table caption-top" style="margin-left: 50px; margin-right: 50px; margin-top: 15px;" >
  <thead>
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
      <td>
        <p><a href="#"><?php echo e($user->name); ?></a></p>
      </td>
      <td><p><?php echo e($user->email); ?></p></td>
      <td>
            <form action="/homepage/<?php echo e($user->id); ?>/profile" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-danger">Clear</button>
                    </form>
        </td>
    </tr>
    
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/list_user.blade.php ENDPATH**/ ?>