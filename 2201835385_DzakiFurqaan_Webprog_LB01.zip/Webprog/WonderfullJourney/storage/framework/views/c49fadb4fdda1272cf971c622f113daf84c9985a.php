
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>

<h1>Welcome <?php echo e(Auth::user()->name); ?></h1>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/welcome.blade.php ENDPATH**/ ?>