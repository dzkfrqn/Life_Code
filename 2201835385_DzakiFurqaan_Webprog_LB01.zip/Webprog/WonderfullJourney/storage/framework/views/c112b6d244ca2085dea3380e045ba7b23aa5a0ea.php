
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row">
            <div class="col">
            <br>
            <img class="card-img rounded float-left" style="width: 400px;height:400px" 
                src="<?php echo e(Storage::url($article->image )); ?>" alt="image not found">  
            </div>
            <div class="col">
            
                <div class="col-7 card-body mx-auto">
                <h2><?php echo e($article->title); ?></h2>
                    <p class="text-justify card-text"><?php echo e($article->description); ?></p>
                    <a class="btn btn-dark mt-auto ml-auto" href="<?php echo e(url()->previous()); ?>">Back</a>
                </div>

            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/detail.blade.php ENDPATH**/ ?>