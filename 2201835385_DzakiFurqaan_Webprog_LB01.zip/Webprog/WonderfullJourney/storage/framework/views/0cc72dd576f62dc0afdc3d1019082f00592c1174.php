<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="icon" href="icon.png">
        <title>Wonderfull Journey</title>
        

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    </head>

<body>
    <header>

        <div class="title m-b-md" style="text-align: center;">
            <h1 style="font-family: Ink Free; text-shadow: 2px 5px 8px black;" >Wonderfull Journey</h1>
            <h5>Blog of Indonesia Tourism</h5>
        </div>
        <nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Explore</a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                            Categories
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="/homepage/categories/1">Mountain</a>
                            <a class="dropdown-item" href="/homepage/categories/2">Beach</a>
                            <a class="dropdown-item" href="/homepage/categories/3">Jungle</a>
                            <a class="dropdown-item" href="/homepage/categories/4">waterfall</a>
                        </div>
                    </li>
                <li class="nav-item">
                    <a class="nav-link" href="/about-us">AboutUs</a>
                </li>
                <?php if(auth()->guard()->guest()): ?>
                
                <li class="nav-item">
                    <a class="nav-link" href="/register">SignUp</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/login">Login</a>
                </li>
                <?php else: ?> <!--User-->
                    <?php if(Auth::user()->role === 'user'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/profile">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/blog">Blog</a>
                        </li>
                    <?php else: ?> <!--admin-->
                        <li class="nav-item">
                            <a class="nav-link" href="/profile">Profile Admin</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="/list-user">User</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/logout">logout</a>
                    </li>
                <?php endif; ?>
                
            </div>
            </ul>
            
        </nav>
    </header> 
    <?php echo $__env->yieldContent('content'); ?> 
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" 
            integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" 
            crossorigin="anonymous">
            </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" 
            integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" 
            crossorigin="anonymous">
            </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
            integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" 
            crossorigin="anonymous">
            </script> 
</body>




<?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/master.blade.php ENDPATH**/ ?>