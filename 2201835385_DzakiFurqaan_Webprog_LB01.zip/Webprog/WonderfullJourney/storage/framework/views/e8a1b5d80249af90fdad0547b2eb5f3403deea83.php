
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>


        <div class="card-body">  
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <div class="row">
                
                <div class="col-md-4">
                    <div class="card-body">
                        <h4 class="card-title"style="font:black;">
                        <p ><?php echo e($article->title); ?></p>
                        </h4>                 
                        <p class="card-text text-muted">
                        <?php echo e(substr($article->description, 0, 80)); ?> 
                        <a href="/homepage/<?php echo e($article->id); ?>/detail">...read more</a>
                        </p>
                    </div>
                </div>    
            </div>
             
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>    
    <div>
    <?php echo e($articles->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/homeActivity.blade.php ENDPATH**/ ?>