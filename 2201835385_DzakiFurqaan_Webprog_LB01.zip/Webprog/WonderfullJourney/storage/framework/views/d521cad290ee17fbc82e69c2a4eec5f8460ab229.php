
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>

<div style="text-align: center">
    <div>
        <a href="/blog/add" class="btn btn-secondary" 
        role="button">+ Create Blog</a>
    </div>

    <div>
        <table class="table table-striped"> 
        <tr>
            <th scope="col">Title</th>
            <th scope="col">Action</th>
        </tr>
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
             
                <td><?php echo e($article->title); ?></td>
                <td>
                    <form action="/blog/<?php echo e($article->id); ?>" method="post">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                            <button class="btn btn-secondary">
                                delete
                            </button> 
                    </form>

                </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/blog.blade.php ENDPATH**/ ?>