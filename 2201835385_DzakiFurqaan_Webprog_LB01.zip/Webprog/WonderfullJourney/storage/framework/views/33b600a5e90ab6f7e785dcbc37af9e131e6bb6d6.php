
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>


<h1 >

ini blog untuk uas

</h1>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 5\UAS\Webprog\WonderfullJourney\resources\views/About.blade.php ENDPATH**/ ?>