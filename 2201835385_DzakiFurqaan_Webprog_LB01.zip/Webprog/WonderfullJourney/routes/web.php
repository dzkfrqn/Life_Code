<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//home
Route::get('/', function () {
    return redirect('/homepage');
});
Route::get('/homepage', 'HomeController@home');

//detail in homepage
Route::get('/homepage/{article_id}/detail','HomeController@detail');

//categories
Route::get('/homepage/categories', 'HomeController@listCategory');
Route::get('/homepage/categories/{category_id}', 'HomeController@show_article_category');

//register
Route::get('/register','RegisterController@form');
Route::post('/register','RegisterController@register');

//login
Route::get('/login','LoginController@form');
Route::post('/login','LoginController@login');
Route::get('/logout','LoginController@logout');
Route::get('/welcome','LoginController@welcome');

//edit profile
Route::get('/profile','UserController@edit');
Route::patch('/profile','UserController@edited');

//blog menu
Route::get('/blog','UserController@blog');
Route::delete('/blog/{article_id}','UserController@delete');
Route::get('/blog/add','UserController@formblog');
Route::post('/blog/add','UserController@add');

//about
Route::get('/about-us','HomeController@showAbout');

//admin
Route::get('/list-user', 'AdminController@ListUser');
Route::delete('/homepage/{user_id}/profile', 'AdminController@delete');




