<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => 'Admin',
            'email' => 'admin@wonderfull.com',
            'role' => 'Admin',
            'phone' => '12345678910',
            'password' => Hash::make('admin')
        ]);
        DB::table('users')->insert([
            'name' => 'user',
            'email' => 'user@wonderfull.com',
            'role' => 'user',
            'phone' => '0812345678',
            'password' => Hash::make('user123')
        ]);
        DB::table('users')->insert([
            'name' => 'dzaki',
            'email' => 'dzaki@wonderfull.com',
            'role' => 'user',
            'phone' => '0812345678',
            'password' => Hash::make('user123')
        ]);
        DB::table('users')->insert([
            'name' => 'furqaan',
            'email' => 'furqaan@wonderfull.com',
            'role' => 'user',
            'phone' => '0812345678',
            'password' => Hash::make('user123')
        ]);
        
    }
}
