<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('articles')->insert([
            'user_id' => 2,
            'category_id' => 2,
            'title' => 'Pantai Kuta, Bali',
            'description' => 'Pantai Kuta adalah sebuah tempat pariwisata yang terletak kecamatan Kuta, sebelah 
                            selatan Kota Denpasar, Bali, Indonesia. Daerah ini merupakan sebuah tujuan wisata turis 
                            mancanegara dan telah menjadi objek wisata andalan Pulau Bali sejak awal tahun 1970-an',
            'image' => 'image/kuta.jpg'            

        ]);
        DB::table('articles')->insert([
            'user_id' => 3,
            'category_id' => 2,
            'title' => 'Pantai Melur, batam',
            'description' => 'pantai yang sangat indah jika kita tidak melihatnya',
            'image' => 'image/melur.png'            

        ]);
        DB::table('articles')->insert([
            'user_id' => 4,
            'category_id' => 2,
            'title' => 'pantai Vio, batam',
            'description' => 'banyak pasir bertebaran',
            'image' => 'image/melur.png'            

        ]);          
        DB::table('articles')->insert([
            'user_id' => 2,
            'category_id' => 1,
            'title' => 'Gunung Gede',
            'description' => 'Gunung yng ingin dinaiki oleh sulton khak',
            'image' => 'image/gede.jpg'            

        ]);
        DB::table('articles')->insert([
            'user_id' => 3,
            'category_id' => 4,
            'title' => 'Air Terjun Niagara, Kolombia',
            'description' => 'Banyak Aer',
            'image' => 'image/aer.jpg'            

        ]);
        DB::table('articles')->insert([
            'user_id' => 3,
            'category_id' => 4,
            'title' => 'Curug Bidadari, Bogor',
            'description' => 'Di Bogor',
            'image' => 'image/curug.jpg'            

        ]);
        DB::table('articles')->insert([
            'user_id' => 4,
            'category_id' => 3,
            'title' => 'Hutan Amazon, Brazil',
            'description' => 'Banyak Hewan Buas',
            'image' => 'image/amajon.jpg'            

        ]);
        DB::table('articles')->insert([
            'user_id' => 3,
            'category_id' => 3,
            'title' => 'Hutan Lindung',
            'description' => 'Banyak yang berlindung',
            'image' => 'image/lindung.jpg'            

        ]);
            
    }
}
