<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    function form(){
        return view('register');
    }

    function register(Request $request){
        $this->validator($request);

        $user = new User();

        $user['name'] = $request['name'];
        $user['email'] = $request['email'];
        $user['phone'] = $request['phone'];
        $user['password'] = Hash::make($request['password']);
        $user->save();

        return redirect('/homepage');
        
    }

    function validator(Request $request){
        return $request->validate([
            'name' => ['required','string'],
            'email' => ['required','string','email','unique:users'],
            'phone' => ['required'],
            'password' => ['required','min:3','string','confirmed'],
        ]);
    }
}
