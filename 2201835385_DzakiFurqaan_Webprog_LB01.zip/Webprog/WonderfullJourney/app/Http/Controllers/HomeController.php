<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Article;

class HomeController extends Controller
{
    //paginate
    function home(){
        $articles = DB::table('articles')
        ->join('categories', 'articles.category_id', '=', 'categories.id')
        ->select('articles.*', 'categories.name as category_name', 'categories.id as category_id')
        ->paginate(3);
        return view('homeActivity')->with('articles',$articles);
    }

    //show detail
    function detail($article_id){
        // dd($article_id);
        $article = Article::where('id', $article_id)->first();
        return view('detail')->with('article',$article);
    }

    //show the list of category
    public function listCategory(){
        $categories = DB::table('categories')
            ->get();
        return view('category')->with('categories',$categories);
    }

    function show_article_category($category_id){
        $articles = DB::table('categories')
            ->where('categories.id', '=', $category_id)
            ->join('articles', 'categories.id', '=', 'articles.category_id')
            ->select('articles.*', 'categories.name as category_name', 'categories.id as category_id')
            ->paginate(6);
        $category_name = DB::table('categories')
            ->where('id', '=', $category_id)
            ->select('name')
            ->first();
        return view('homeActivity')
            ->with('articles', $articles)
            ->with('category_name', $category_name);
    }

    function showAbout(){

        return view('About');
    }

}



