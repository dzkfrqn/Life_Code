<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Article;


class AdminController extends Controller
{
    //show the article that the user write (login)
    function ListUser(){
        $users = DB::table('users')
            ->where('role', '=', "User")
            ->paginate(3);
        return view('list_user')->with('users', $users);
    }

    // delete 1 user of the admin choice
    public function delete($user_id){
        //check if the the user have articles
        if (Article::where('user_id', '=', $user_id)->exists()){
            //delete the old image in the storage
            $images = DB::table('articles')
                ->where('id', '=', $user_id)
                ->select('image')->get();
            foreach ($images as $image){
//                dd($image->image);
                Storage::disk('public')->delete($image->image);
            }
        }


        //delete the data
        DB::table('users')
            ->where('id', '=', $user_id)
            ->delete();
        return redirect('/list-user');
    }
}
